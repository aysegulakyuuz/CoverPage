import React from 'react';
import './App.css';

const Home = () => {
  return (
    <div className='HomePage'>
      <h2>Home Page</h2>
      <p>Welcome! This is the home page of the application.</p>
      <div className="Image">
       
        
      </div>
      <div className="card-block">
        <h4 >IMAGE</h4>
      </div>
    </div>
  );
};

export default Home;


